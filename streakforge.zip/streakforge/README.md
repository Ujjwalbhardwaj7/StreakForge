# StreakForge

Gamified daily-mission tracker. Next.js 14 (App Router) + TypeScript + Tailwind + Framer Motion.

## Run it

```bash
npm install
npm run dev
```

Then open http://localhost:3000 for the landing page, or
http://localhost:3000/mission-control for the dashboard.

> This project was scaffolded in a sandbox with no network access, so
> `npm install` has not been run and the dev server has not been started
> against these files. Everything is written to match Next 14 / React 18 /
> Tailwind 3 APIs exactly, but do a `npm run build` locally as a first
> sanity check.

## Structure

```
app/
  (marketing)/page.tsx        landing page
  (app)/layout.tsx            shell: top nav (desktop) / bottom nav (mobile)
  (app)/mission-control/      dashboard: streak, XP, missions, badges, coach
  (app)/mission/[id]/         mission detail
  (app)/submit/[missionId]/   3-step log flow + celebration sequence
components/
  ui/         reskinned shadcn-style primitives (button, card, badge, progress)
  streak/     StreakForgeBar — signature "molten gauge" streak meter
  xp/         XPBar, XPOrb
  badges/     BadgeCard, BadgeGrid
  coach/      AICoach
  missions/   MissionCard
  shared/     EmptyState
  layout/     BottomNav (renders as top nav on desktop)
lib/
  mock-data.ts   mock user, missions, badges, leaderboard — swap for real
                 API calls later, the shapes are the contract
  motion.ts      shared Framer Motion variants (fadeUp, stagger, celebration)
  utils.ts       cn() helper
```

## Design tokens

Gradients are defined as CSS variables in `app/globals.css`
(`--gradient-primary`, `--gradient-success`, `--gradient-gold`) and exposed
to Tailwind as `bg-gradient-primary` / `bg-gradient-success` / `bg-gradient-gold`.

Radius scale: `rounded-sm` (12px) / `rounded-md` (16px) / `rounded-lg` (24px) — used consistently across all cards.

## Wiring to a real backend

`lib/mock-data.ts` is the seam. Each page reads from it directly; swap the
imports for fetch calls / server actions returning the same shapes
(`Mission`, `Badge`, `LeaderboardEntry`, `UserProfile`) and the components
don't need to change.
