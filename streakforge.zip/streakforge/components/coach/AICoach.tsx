"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, ChevronRight, RefreshCcw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { coachTips } from "@/lib/mock-data";

interface AICoachProps {
  className?: string;
}

export function AICoach({ className }: AICoachProps) {
  const [index, setIndex] = useState(0);
  const tip = coachTips[index % coachTips.length];

  return (
    <Card className={className}>
      <CardContent className="flex items-start gap-3 pt-5">
        <div className="mt-0.5 flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-gradient-primary">
          <Sparkles className="h-4 w-4 text-forge-bg" />
        </div>

        <div className="min-w-0 flex-1">
          <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-forge-ember">
            Coach
          </p>
          <AnimatePresence mode="wait">
            <motion.p
              key={tip}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
              className="text-sm leading-relaxed text-forge-text"
            >
              {tip}
            </motion.p>
          </AnimatePresence>

          <div className="mt-3 flex items-center gap-2">
            <Button
              size="sm"
              variant="ghost"
              className="h-8 px-2"
              onClick={() => setIndex((i) => i + 1)}
            >
              <RefreshCcw className="h-3.5 w-3.5" /> Another tip
            </Button>
            <Button size="sm" variant="ghost" className="h-8 px-2">
              Apply <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
