"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Flame, Zap, CheckCircle2, XCircle, Circle } from "lucide-react";
import { BadgeUI } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { Mission } from "@/lib/mock-data";
import { staggerChild } from "@/lib/motion";

const STATUS_CONFIG: Record<
  Mission["status"],
  { label: string; icon: typeof Circle; badgeVariant: "default" | "ember" | "success" }
> = {
  not_started: { label: "Not started", icon: Circle, badgeVariant: "default" },
  in_progress: { label: "In progress", icon: Zap, badgeVariant: "ember" },
  completed: { label: "Completed", icon: CheckCircle2, badgeVariant: "success" },
  missed: { label: "Missed", icon: XCircle, badgeVariant: "default" },
};

export function MissionCard({ mission }: { mission: Mission }) {
  const status = STATUS_CONFIG[mission.status];
  const StatusIcon = status.icon;
  const isActionable = mission.status === "not_started" || mission.status === "in_progress";

  return (
    <motion.div
      variants={staggerChild}
      className={cn(
        "group relative flex items-center justify-between gap-4 rounded-md border border-forge-border bg-forge-surface p-4 transition-colors hover:border-forge-ember/40",
        mission.status === "missed" && "opacity-70"
      )}
    >
      <div className="min-w-0 flex-1">
        <div className="mb-1.5 flex items-center gap-2">
          <BadgeUI variant={status.badgeVariant}>
            <StatusIcon className="h-3 w-3" />
            {status.label}
          </BadgeUI>
          {mission.streakDays > 0 && (
            <span className="flex items-center gap-1 text-xs text-forge-ember">
              <Flame className="h-3 w-3" /> {mission.streakDays}d
            </span>
          )}
        </div>
        {/* stretched link covers the whole card for the "view detail" action */}
        <Link href={`/mission/${mission.id}`} className="static">
          <span className="absolute inset-0" aria-hidden="true" />
          <p className="truncate font-display text-sm font-bold text-forge-text">
            {mission.title}
          </p>
        </Link>
        <p className="mt-0.5 truncate text-xs text-forge-muted">{mission.dueLabel}</p>
      </div>

      <div className="relative z-10 flex flex-shrink-0 flex-col items-end gap-2">
        <span className="font-mono text-xs font-semibold text-forge-gold">
          +{mission.xpReward} XP
        </span>
        {isActionable && (
          <Link
            href={`/submit/${mission.id}`}
            className="rounded-sm bg-forge-surface2 px-2.5 py-1 text-[11px] font-semibold text-forge-text transition-colors hover:bg-gradient-primary hover:text-forge-bg"
          >
            Log it
          </Link>
        )}
      </div>
    </motion.div>
  );
}
