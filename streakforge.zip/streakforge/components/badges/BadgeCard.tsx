"use client";

import { motion } from "framer-motion";
import { Trophy, Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Badge } from "@/lib/mock-data";
import { popIn } from "@/lib/motion";

const TIER_GRADIENT: Record<Badge["tier"], string> = {
  bronze: "from-[#B87333] to-[#8A5A2E]",
  silver: "from-[#C7CDD6] to-[#8B93A3]",
  gold: "bg-gradient-gold",
};

export function BadgeCard({ badge }: { badge: Badge }) {
  return (
    <motion.div
      variants={popIn}
      className={cn(
        "flex flex-col items-center gap-2 rounded-md border p-4 text-center",
        badge.earned
          ? "border-forge-border bg-forge-surface2"
          : "border-forge-border/50 bg-forge-surface2/40"
      )}
    >
      <div
        className={cn(
          "flex h-12 w-12 items-center justify-center rounded-full",
          badge.earned
            ? badge.tier === "gold"
              ? "bg-gradient-gold"
              : `bg-gradient-to-br ${TIER_GRADIENT[badge.tier]}`
            : "bg-forge-surface2 ring-1 ring-forge-border"
        )}
      >
        {badge.earned ? (
          <Trophy className="h-5 w-5 text-forge-bg" />
        ) : (
          <Lock className="h-4 w-4 text-forge-faint" />
        )}
      </div>
      <div>
        <p className={cn("text-sm font-semibold", badge.earned ? "text-forge-text" : "text-forge-faint")}>
          {badge.name}
        </p>
        <p className="mt-0.5 text-xs text-forge-faint">
          {badge.earned ? `Earned ${badge.earnedOn}` : badge.description}
        </p>
      </div>
    </motion.div>
  );
}
