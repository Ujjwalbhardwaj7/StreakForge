"use client";

import { motion } from "framer-motion";
import { BadgeCard } from "./BadgeCard";
import type { Badge } from "@/lib/mock-data";
import { staggerParent, staggerChild } from "@/lib/motion";

export function BadgeGrid({ badges }: { badges: Badge[] }) {
  if (badges.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-forge-faint">
        No badges yet — complete a mission to earn your first one.
      </p>
    );
  }

  return (
    <motion.div
      variants={staggerParent}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-40px" }}
      className="grid grid-cols-3 gap-3"
    >
      {badges.map((badge) => (
        <motion.div key={badge.id} variants={staggerChild}>
          <BadgeCard badge={badge} />
        </motion.div>
      ))}
    </motion.div>
  );
}
