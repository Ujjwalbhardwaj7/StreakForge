"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Flame, LayoutGrid, Trophy, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/mission-control", label: "Missions", icon: LayoutGrid },
  { href: "/mission-control#streak", label: "Streak", icon: Flame },
  { href: "/mission-control#badges", label: "Badges", icon: Trophy },
  { href: "/mission-control#coach", label: "Coach", icon: Sparkles },
] as const;

export function BottomNav() {
  const pathname = usePathname();

  return (
    <>
      {/* mobile: fixed bottom tab bar */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-40 border-t border-forge-border bg-forge-surface/95 backdrop-blur-md md:hidden"
        aria-label="Primary"
      >
        <ul className="mx-auto flex max-w-lg items-stretch justify-between px-2">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const active = pathname === "/mission-control" && href === "/mission-control";
            return (
              <li key={href} className="flex-1">
                <Link
                  href={href}
                  className={cn(
                    "flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium transition-colors",
                    active ? "text-forge-ember" : "text-forge-faint hover:text-forge-muted"
                  )}
                >
                  <Icon className="h-5 w-5" strokeWidth={active ? 2.4 : 2} aria-hidden="true" />
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* desktop: slim top nav, same links */}
      <nav
        className="sticky top-0 z-40 hidden border-b border-forge-border bg-forge-surface/80 backdrop-blur-md md:block"
        aria-label="Primary"
      >
        <ul className="mx-auto flex max-w-3xl items-center gap-1 px-2 py-2">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const active = pathname === "/mission-control" && href === "/mission-control";
            return (
              <li key={href}>
                <Link
                  href={href}
                  className={cn(
                    "flex items-center gap-1.5 rounded-sm px-3 py-1.5 text-sm font-medium transition-colors",
                    active
                      ? "bg-forge-ember/10 text-forge-ember"
                      : "text-forge-muted hover:bg-forge-surface2 hover:text-forge-text"
                  )}
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}
