"use client";

import { motion } from "framer-motion";
import { Flame } from "lucide-react";
import { cn } from "@/lib/utils";

interface StreakForgeBarProps {
  currentStreak: number;
  longestStreak: number;
  className?: string;
}

// Signature element: a molten "forge gauge" — the streak bar reads like a
// heated metal strip, with ember particles drifting off the lit portion.
export function StreakForgeBar({
  currentStreak,
  longestStreak,
  className,
}: StreakForgeBarProps) {
  const pct = Math.min(100, Math.round((currentStreak / Math.max(longestStreak, 1)) * 100));

  return (
    <div className={cn("relative", className)}>
      <div className="mb-2 flex items-end justify-between">
        <div className="flex items-center gap-1.5">
          <Flame className="h-4 w-4 text-forge-ember animate-ember-flicker" />
          <span className="font-mono text-2xl font-bold text-forge-text">
            {currentStreak}
          </span>
          <span className="text-sm text-forge-muted">day streak</span>
        </div>
        <span className="text-xs text-forge-faint">
          Best: <span className="font-mono text-forge-muted">{longestStreak}d</span>
        </span>
      </div>

      <div className="relative h-4 w-full overflow-hidden rounded-sm bg-forge-surface2 ring-1 ring-inset ring-forge-border">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="relative h-full bg-gradient-primary"
        >
          {/* drifting ember particles along the lit edge */}
          <span className="absolute right-0 top-1/2 h-1.5 w-1.5 -translate-y-1/2 translate-x-1/2 rounded-full bg-forge-gold animate-float-up" />
          <span
            className="absolute right-3 top-1/2 h-1 w-1 -translate-y-1/2 rounded-full bg-forge-gold/80 animate-float-up"
            style={{ animationDelay: "0.4s" }}
          />
        </motion.div>
      </div>
    </div>
  );
}
