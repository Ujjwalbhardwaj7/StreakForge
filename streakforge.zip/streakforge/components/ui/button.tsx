import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-forge-ember focus-visible:ring-offset-2 focus-visible:ring-offset-forge-bg disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary:
          "bg-gradient-primary text-forge-bg shadow-[0_0_0_1px_rgba(255,107,53,0.25),0_8px_24px_-8px_rgba(255,107,53,0.55)] hover:brightness-110 active:brightness-95",
        gold:
          "bg-gradient-gold text-forge-bg shadow-[0_0_0_1px_rgba(255,200,87,0.25),0_8px_24px_-8px_rgba(255,200,87,0.55)] hover:brightness-110",
        secondary:
          "bg-forge-surface2 text-forge-text border border-forge-border hover:border-forge-ember/50 hover:bg-forge-surface2/80",
        ghost: "text-forge-muted hover:text-forge-text hover:bg-forge-surface2",
        outline:
          "border border-forge-border text-forge-text hover:border-forge-ember/60 hover:text-forge-ember",
      },
      size: {
        sm: "h-9 px-3.5 text-xs",
        md: "h-11 px-5",
        lg: "h-14 px-7 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
