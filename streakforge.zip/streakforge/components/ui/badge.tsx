import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-xs font-semibold tracking-wide",
  {
    variants: {
      variant: {
        default: "bg-forge-surface2 text-forge-muted border border-forge-border",
        ember: "bg-forge-ember/15 text-forge-ember border border-forge-ember/30",
        gold: "bg-forge-gold/15 text-forge-gold border border-forge-gold/30",
        success: "bg-forge-emerald/15 text-forge-emerald border border-forge-emerald/30",
        outline: "border border-forge-border text-forge-text",
      },
    },
    defaultVariants: { variant: "default" },
  }
);

export interface BadgeUIProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

function BadgeUI({ className, variant, ...props }: BadgeUIProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { BadgeUI, badgeVariants };
