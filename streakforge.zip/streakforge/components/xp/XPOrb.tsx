"use client";

import { motion, AnimatePresence } from "framer-motion";

interface XPOrbProps {
  amount: number;
  show: boolean;
}

// A small "+XP" callout that pops and floats up — used right after a
// mission is marked complete, before the full celebration sequence.
export function XPOrb({ amount, show }: XPOrbProps) {
  return (
    <AnimatePresence>
      {show && (
        <motion.span
          initial={{ opacity: 0, y: 0, scale: 0.7 }}
          animate={{ opacity: 1, y: -28, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="pointer-events-none absolute -top-1 right-2 font-mono text-sm font-bold text-forge-gold"
        >
          +{amount} XP
        </motion.span>
      )}
    </AnimatePresence>
  );
}
