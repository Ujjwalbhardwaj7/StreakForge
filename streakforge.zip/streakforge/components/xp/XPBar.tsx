"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface XPBarProps {
  level: number;
  xp: number;
  xpToNextLevel: number;
  className?: string;
}

export function XPBar({ level, xp, xpToNextLevel, className }: XPBarProps) {
  const pct = Math.min(100, Math.round((xp / xpToNextLevel) * 100));

  return (
    <div className={cn("", className)}>
      <div className="mb-2 flex items-center justify-between text-xs">
        <span className="font-semibold text-forge-gold">Level {level}</span>
        <span className="font-mono text-forge-faint">
          {xp.toLocaleString()} / {xpToNextLevel.toLocaleString()} XP
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-sm bg-forge-surface2 ring-1 ring-inset ring-forge-border">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="h-full bg-gradient-gold"
        />
      </div>
    </div>
  );
}
