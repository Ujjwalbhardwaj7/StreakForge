"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Flame, ArrowRight, Zap, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fadeUp, staggerParent, staggerChild } from "@/lib/motion";
import { mockUser, mockLeaderboard } from "@/lib/mock-data";

export default function LandingPage() {
  return (
    <div className="min-h-screen overflow-hidden bg-forge-bg">
      {/* ambient ember glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-0 h-[520px] w-[820px] -translate-x-1/2 rounded-full opacity-20 blur-[120px]"
        style={{ background: "var(--gradient-primary)" }}
      />

      <header className="relative mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <Flame className="h-5 w-5 text-forge-ember" />
          <span className="font-display text-lg font-bold">StreakForge</span>
        </div>
        <Link href="/mission-control">
          <Button variant="secondary" size="sm">
            Open dashboard
          </Button>
        </Link>
      </header>

      {/* Hero */}
      <section className="relative mx-auto flex max-w-4xl flex-col items-center px-6 pb-20 pt-12 text-center md:pt-20">
        <motion.div variants={fadeUp} initial="hidden" animate="show">
          <span className="inline-flex items-center gap-1.5 rounded-sm border border-forge-ember/30 bg-forge-ember/10 px-3 py-1 text-xs font-semibold text-forge-ember">
            <Zap className="h-3.5 w-3.5" /> Day {mockUser.currentStreak} and still burning
          </span>
        </motion.div>

        <motion.h1
          variants={fadeUp}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.05 }}
          className="mt-6 font-display text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl"
        >
          Every streak starts
          <br />
          <span className="bg-gradient-primary bg-clip-text text-transparent">
            as a single ember.
          </span>
        </motion.h1>

        <motion.p
          variants={fadeUp}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.1 }}
          className="mt-5 max-w-xl text-balance text-base text-forge-muted md:text-lg"
        >
          StreakForge turns your daily habits into missions with real stakes —
          XP, streaks, and badges that actually mean something because
          missing a day actually costs you something.
        </motion.p>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          transition={{ delay: 0.15 }}
          className="mt-8 flex flex-col gap-3 sm:flex-row"
        >
          <Link href="/mission-control">
            <Button size="lg" className="group">
              Start your first mission
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </Button>
          </Link>
          <Button size="lg" variant="outline">
            See how it works
          </Button>
        </motion.div>
      </section>

      {/* Proof strip: today's forge — a live-feeling leaderboard snapshot */}
      <section className="relative mx-auto max-w-4xl px-6 pb-24">
        <motion.div
          variants={staggerParent}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="rounded-lg border border-forge-border bg-forge-surface p-6 md:p-8"
        >
          <motion.div
            variants={staggerChild}
            className="mb-6 flex items-center justify-between"
          >
            <div className="flex items-center gap-2 text-sm font-semibold text-forge-muted">
              <Users className="h-4 w-4" /> Forged this week
            </div>
            <span className="font-mono text-xs text-forge-faint">Live snapshot</span>
          </motion.div>

          <div className="space-y-3">
            {mockLeaderboard.slice(0, 4).map((entry) => (
              <motion.div
                key={entry.id}
                variants={staggerChild}
                className="flex items-center justify-between rounded-sm border border-forge-border/60 bg-forge-surface2/60 px-4 py-3"
              >
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs text-forge-faint w-4">
                    {String(entry.rank).padStart(2, "0")}
                  </span>
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-gold text-xs font-bold text-forge-bg">
                    {entry.avatarInitial}
                  </div>
                  <span className="text-sm font-medium">{entry.name}</span>
                </div>
                <div className="flex items-center gap-4 text-xs">
                  <span className="flex items-center gap-1 text-forge-ember">
                    <Flame className="h-3.5 w-3.5" /> {entry.streakDays}d
                  </span>
                  <span className="font-mono text-forge-muted">{entry.xp.toLocaleString()} XP</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      <footer className="border-t border-forge-border px-6 py-8 text-center text-xs text-forge-faint">
        StreakForge — built to be broken into a real backend later.
      </footer>
    </div>
  );
}
