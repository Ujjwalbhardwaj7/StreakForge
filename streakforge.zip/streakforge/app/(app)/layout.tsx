import { BottomNav } from "@/components/layout/BottomNav";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-forge-bg">
      <BottomNav />
      <main className="mx-auto max-w-lg pb-24 md:max-w-3xl md:pb-10">{children}</main>
    </div>
  );
}
