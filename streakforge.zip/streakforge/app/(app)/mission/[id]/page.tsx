"use client";

import { notFound, useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Flame, ListChecks, CircleDot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BadgeUI } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { getMissionById } from "@/lib/mock-data";
import { fadeUp, staggerParent, staggerChild } from "@/lib/motion";

const DIFFICULTY_LABEL: Record<string, string> = {
  easy: "Easy",
  medium: "Medium",
  hard: "Hard",
};

export default function MissionDetailPage({ params }: { params: { id: string } }) {
  const mission = getMissionById(params.id);
  const router = useRouter();

  if (!mission) notFound();

  const isActionable = mission.status === "not_started" || mission.status === "in_progress";

  return (
    <div className="px-4 pt-6 md:px-0">
      <button
        onClick={() => router.back()}
        className="mb-5 flex items-center gap-1.5 text-sm text-forge-muted hover:text-forge-text"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      <motion.div variants={fadeUp} initial="hidden" animate="show">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <BadgeUI variant="outline" className="capitalize">
            {mission.category}
          </BadgeUI>
          <BadgeUI variant="default">{DIFFICULTY_LABEL[mission.difficulty]}</BadgeUI>
          {mission.streakDays > 0 && (
            <span className="flex items-center gap-1 text-xs text-forge-ember">
              <Flame className="h-3.5 w-3.5" /> {mission.streakDays} day streak
            </span>
          )}
        </div>

        <h1 className="font-display text-2xl font-bold leading-tight">{mission.title}</h1>
        <p className="mt-2 text-sm leading-relaxed text-forge-muted">{mission.description}</p>

        <div className="mt-4 flex items-center gap-4 text-xs">
          <span className="font-mono font-semibold text-forge-gold">
            +{mission.xpReward} XP
          </span>
          <span className="text-forge-faint">{mission.dueLabel}</span>
        </div>
      </motion.div>

      <Card className="my-6">
        <CardContent className="pt-5">
          <h2 className="mb-3 flex items-center gap-1.5 font-display text-sm font-bold">
            <ListChecks className="h-4 w-4 text-forge-ember" /> How it&apos;s scored
          </h2>
          <motion.ul
            variants={staggerParent}
            initial="hidden"
            animate="show"
            className="space-y-2.5"
          >
            {mission.steps.map((step, i) => (
              <motion.li
                key={i}
                variants={staggerChild}
                className="flex items-start gap-2.5 text-sm text-forge-text"
              >
                <CircleDot className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-forge-faint" />
                {step}
              </motion.li>
            ))}
          </motion.ul>
        </CardContent>
      </Card>

      {isActionable ? (
        <Link href={`/submit/${mission.id}`}>
          <Button size="lg" className="w-full">
            Log this mission
          </Button>
        </Link>
      ) : mission.status === "completed" ? (
        <Button size="lg" variant="secondary" className="w-full" disabled>
          Already completed today
        </Button>
      ) : (
        <Button size="lg" variant="outline" className="w-full" disabled>
          Missed — resets tomorrow
        </Button>
      )}
    </div>
  );
}
