"use client";

import { motion } from "framer-motion";
import { ListChecks } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { StreakForgeBar } from "@/components/streak/StreakForgeBar";
import { XPBar } from "@/components/xp/XPBar";
import { BadgeGrid } from "@/components/badges/BadgeGrid";
import { MissionCard } from "@/components/missions/MissionCard";
import { AICoach } from "@/components/coach/AICoach";
import { EmptyState } from "@/components/shared/EmptyState";
import { mockUser, mockMissions, mockBadges } from "@/lib/mock-data";
import { fadeUp, staggerParent } from "@/lib/motion";

export default function MissionControlPage() {
  const activeMissions = mockMissions.filter((m) => m.status !== "completed");
  const completedToday = mockMissions.filter((m) => m.status === "completed");

  return (
    <div className="px-4 pt-6 md:px-0">
      <motion.header variants={fadeUp} initial="hidden" animate="show" className="mb-6">
        <p className="text-sm text-forge-muted">Welcome back,</p>
        <h1 className="font-display text-2xl font-bold">{mockUser.name.split(" ")[0]}</h1>
      </motion.header>

      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="show"
        transition={{ delay: 0.05 }}
      >
        <Card id="streak" className="mb-4">
          <CardContent className="pt-5">
            <StreakForgeBar
              currentStreak={mockUser.currentStreak}
              longestStreak={mockUser.longestStreak}
            />
            <div className="my-5 h-px bg-forge-border" />
            <XPBar
              level={mockUser.level}
              xp={mockUser.xp}
              xpToNextLevel={mockUser.xpToNextLevel}
            />
          </CardContent>
        </Card>
      </motion.div>

      <section className="mb-6">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-1.5 font-display text-sm font-bold text-forge-text">
            <ListChecks className="h-4 w-4 text-forge-ember" /> Today&apos;s missions
          </h2>
          <span className="text-xs text-forge-faint">
            {completedToday.length}/{mockMissions.length} done
          </span>
        </div>

        {activeMissions.length > 0 ? (
          <motion.div
            variants={staggerParent}
            initial="hidden"
            animate="show"
            className="space-y-2.5"
          >
            {activeMissions.map((mission) => (
              <MissionCard key={mission.id} mission={mission} />
            ))}
          </motion.div>
        ) : (
          <EmptyState
            icon={ListChecks}
            title="All missions forged for today"
            description="Nothing left on the anvil. Check back tomorrow, or add a new mission."
          />
        )}
      </section>

      <section id="badges" className="mb-6">
        <h2 className="mb-3 font-display text-sm font-bold text-forge-text">Badges</h2>
        <BadgeGrid badges={mockBadges} />
      </section>

      <section id="coach" className="mb-6">
        <h2 className="mb-3 font-display text-sm font-bold text-forge-text">Coach</h2>
        <AICoach />
      </section>
    </div>
  );
}
