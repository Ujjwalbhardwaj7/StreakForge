"use client";

import { useState } from "react";
import { notFound, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Check, Camera, MessageSquareText, PartyPopper, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { getMissionById } from "@/lib/mock-data";
import {
  fadeUp,
  celebrationContainer,
  celebrationBadge,
  confettiPiece,
} from "@/lib/motion";

type Step = 1 | 2 | 3 | "celebrate";

const CONFETTI = Array.from({ length: 14 }, (_, i) => ({
  x: (Math.random() - 0.5) * 260,
  y: -(120 + Math.random() * 160),
  rotate: (Math.random() - 0.5) * 360,
  delay: Math.random() * 0.25,
  color: i % 3 === 0 ? "bg-forge-gold" : i % 3 === 1 ? "bg-forge-ember" : "bg-forge-emerald",
}));

export default function SubmitMissionPage({
  params,
}: {
  params: { missionId: string };
}) {
  const mission = getMissionById(params.missionId);
  const router = useRouter();
  const [step, setStep] = useState<Step>(1);
  const [effort, setEffort] = useState<number | null>(null);
  const [note, setNote] = useState("");

  if (!mission) notFound();

  const stepNumber = typeof step === "number" ? step : 3;

  return (
    <div className="flex min-h-screen flex-col px-4 pt-6 md:px-0">
      {step !== "celebrate" && (
        <>
          <button
            onClick={() => router.back()}
            className="mb-5 flex items-center gap-1.5 text-sm text-forge-muted hover:text-forge-text"
          >
            <ArrowLeft className="h-4 w-4" /> Cancel
          </button>

          {/* step progress */}
          <div className="mb-6 flex items-center gap-2">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className={`h-1.5 flex-1 rounded-sm transition-colors ${
                  n <= stepNumber ? "bg-gradient-primary" : "bg-forge-surface2"
                }`}
              />
            ))}
          </div>

          <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-forge-ember">
            Step {stepNumber} of 3
          </p>
          <h1 className="mb-6 font-display text-xl font-bold">{mission.title}</h1>
        </>
      )}

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            variants={fadeUp}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: -12 }}
          >
            <p className="mb-4 text-sm text-forge-muted">
              How much effort did this mission take?
            </p>
            <div className="grid grid-cols-3 gap-2.5">
              {[1, 2, 3].map((val) => (
                <button
                  key={val}
                  onClick={() => setEffort(val)}
                  className={`rounded-md border p-4 text-center transition-colors ${
                    effort === val
                      ? "border-forge-ember bg-forge-ember/10"
                      : "border-forge-border bg-forge-surface hover:border-forge-ember/40"
                  }`}
                >
                  <p className="font-display text-lg font-bold">
                    {"🔥".repeat(val)}
                  </p>
                  <p className="mt-1 text-xs text-forge-muted">
                    {val === 1 ? "Light" : val === 2 ? "Solid" : "Pushed hard"}
                  </p>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="step2"
            variants={fadeUp}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: -12 }}
          >
            <p className="mb-4 flex items-center gap-1.5 text-sm text-forge-muted">
              <MessageSquareText className="h-4 w-4" /> Add a quick note (optional)
            </p>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="What made today's session work — or not?"
              rows={4}
              className="w-full resize-none rounded-md border border-forge-border bg-forge-surface p-3.5 text-sm text-forge-text placeholder:text-forge-faint focus:border-forge-ember/60 focus:outline-none"
            />
            <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-md border border-dashed border-forge-border py-3 text-xs text-forge-faint hover:border-forge-ember/40 hover:text-forge-muted">
              <Camera className="h-4 w-4" /> Attach a photo (optional)
            </button>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div
            key="step3"
            variants={fadeUp}
            initial="hidden"
            animate="show"
            exit={{ opacity: 0, y: -12 }}
          >
            <p className="mb-4 text-sm text-forge-muted">Confirm and log this mission.</p>
            <Card>
              <CardContent className="space-y-3 pt-5 text-sm">
                <Row label="Mission" value={mission.title} />
                <Row
                  label="Effort"
                  value={effort ? "🔥".repeat(effort) : "Not set"}
                />
                <Row label="Note" value={note || "—"} />
                <Row label="XP reward" value={`+${mission.xpReward} XP`} accent />
              </CardContent>
            </Card>
          </motion.div>
        )}

        {step === "celebrate" && (
          <motion.div
            key="celebrate"
            variants={celebrationContainer}
            initial="hidden"
            animate="show"
            className="relative flex flex-1 flex-col items-center justify-center py-16 text-center"
          >
            {/* confetti burst */}
            <div className="pointer-events-none absolute left-1/2 top-1/3">
              {CONFETTI.map((c, i) => (
                <motion.span
                  key={i}
                  custom={c}
                  variants={confettiPiece}
                  className={`absolute h-2 w-2 rounded-sm ${c.color}`}
                />
              ))}
            </div>

            <motion.div
              variants={celebrationBadge}
              className="mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-gold shadow-[0_0_40px_-8px_rgba(255,200,87,0.6)]"
            >
              <Trophy className="h-9 w-9 text-forge-bg" />
            </motion.div>

            <motion.h2
              variants={fadeUp}
              className="font-display text-2xl font-bold"
            >
              Mission forged.
            </motion.h2>
            <motion.p variants={fadeUp} className="mt-2 text-sm text-forge-muted">
              <span className="font-mono font-semibold text-forge-gold">
                +{mission.xpReward} XP
              </span>{" "}
              — streak now at{" "}
              <span className="font-mono font-semibold text-forge-ember">
                {mission.streakDays + 1} days
              </span>
              .
            </motion.p>

            <motion.div variants={fadeUp} className="mt-8 flex gap-3">
              <Button variant="secondary" onClick={() => router.push("/mission-control")}>
                Back to missions
              </Button>
              <Button onClick={() => router.push("/mission-control#badges")}>
                <PartyPopper className="h-4 w-4" /> View badges
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {step !== "celebrate" && (
        <div className="mt-auto pb-6 pt-8">
          <Button
            size="lg"
            className="w-full"
            disabled={step === 1 && effort === null}
            onClick={() => {
              if (step === 1) setStep(2);
              else if (step === 2) setStep(3);
              else setStep("celebrate");
            }}
          >
            {step === 3 ? (
              <>
                <Check className="h-4 w-4" /> Log mission
              </>
            ) : (
              "Continue"
            )}
          </Button>
        </div>
      )}
    </div>
  );
}

function Row({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between border-b border-forge-border/60 pb-3 last:border-0 last:pb-0">
      <span className="text-forge-muted">{label}</span>
      <span className={accent ? "font-mono font-semibold text-forge-gold" : "text-forge-text"}>
        {value}
      </span>
    </div>
  );
}
