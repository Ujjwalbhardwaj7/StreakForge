import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      colors: {
        forge: {
          bg: "#0B0D12",
          surface: "#12151C",
          surface2: "#181C25",
          border: "#232733",
          ember: "#FF6B35",
          "ember-dim": "#B84E27",
          gold: "#FFC857",
          emerald: "#2DD4A7",
          text: "#F1F5F9",
          muted: "#94A3B8",
          faint: "#5A6472",
        },
      },
      borderRadius: {
        sm: "12px",
        md: "16px",
        lg: "24px",
      },
      backgroundImage: {
        "gradient-primary": "var(--gradient-primary)",
        "gradient-success": "var(--gradient-success)",
        "gradient-gold": "var(--gradient-gold)",
      },
      keyframes: {
        "ember-flicker": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.85" },
        },
        "float-up": {
          "0%": { transform: "translateY(0)", opacity: "1" },
          "100%": { transform: "translateY(-40px)", opacity: "0" },
        },
      },
      animation: {
        "ember-flicker": "ember-flicker 2.4s ease-in-out infinite",
        "float-up": "float-up 1.2s ease-out forwards",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
