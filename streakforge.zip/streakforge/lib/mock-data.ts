export type MissionStatus = "not_started" | "in_progress" | "completed" | "missed";
export type MissionDifficulty = "easy" | "medium" | "hard";

export interface Mission {
  id: string;
  title: string;
  description: string;
  category: "focus" | "movement" | "learning" | "wellness";
  difficulty: MissionDifficulty;
  xpReward: number;
  status: MissionStatus;
  streakDays: number;
  dueLabel: string;
  steps: string[];
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  tier: "bronze" | "silver" | "gold";
  earned: boolean;
  earnedOn?: string;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  avatarInitial: string;
  xp: number;
  streakDays: number;
  rank: number;
  isCurrentUser?: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  level: number;
  xp: number;
  xpToNextLevel: number;
  currentStreak: number;
  longestStreak: number;
  missionsCompleted: number;
  badgesEarned: number;
}

export const mockUser: UserProfile = {
  id: "u1",
  name: "Amara Chen",
  level: 14,
  xp: 3420,
  xpToNextLevel: 4000,
  currentStreak: 27,
  longestStreak: 41,
  missionsCompleted: 132,
  badgesEarned: 9,
};

export const mockMissions: Mission[] = [
  {
    id: "m1",
    title: "Deep work block",
    description: "One uninterrupted 45-minute focus session, phone in another room.",
    category: "focus",
    difficulty: "medium",
    xpReward: 80,
    status: "in_progress",
    streakDays: 12,
    dueLabel: "Due today, 6:00 PM",
    steps: [
      "Pick a single task before you start the timer",
      "Close every tab that isn't the task",
      "Work for 45 minutes without switching apps",
    ],
  },
  {
    id: "m2",
    title: "Morning mobility",
    description: "10-minute mobility flow to loosen hips and shoulders before the day starts.",
    category: "movement",
    difficulty: "easy",
    xpReward: 40,
    status: "completed",
    streakDays: 27,
    dueLabel: "Completed at 7:12 AM",
    steps: ["Hip circles, 2 minutes", "Shoulder rolls, 2 minutes", "Cat-cow flow, 6 minutes"],
  },
  {
    id: "m3",
    title: "Read 20 pages",
    description: "Keep momentum on your current book — any 20 pages count.",
    category: "learning",
    difficulty: "easy",
    xpReward: 50,
    status: "not_started",
    streakDays: 5,
    dueLabel: "Due by midnight",
    steps: ["Open your current book", "Read 20 pages, no skimming", "Log one takeaway"],
  },
  {
    id: "m4",
    title: "Wind-down ritual",
    description: "Screens off 30 minutes before bed. Journal or stretch instead.",
    category: "wellness",
    difficulty: "hard",
    xpReward: 100,
    status: "not_started",
    streakDays: 0,
    dueLabel: "Due by 11:00 PM",
    steps: ["Set devices to another room", "Journal 3 lines or stretch 10 minutes", "Lights out"],
  },
  {
    id: "m5",
    title: "Cold outreach, 1 message",
    description: "Send one message that moves a real relationship or opportunity forward.",
    category: "focus",
    difficulty: "medium",
    xpReward: 70,
    status: "missed",
    streakDays: 0,
    dueLabel: "Missed yesterday",
    steps: ["Pick one person", "Write a specific, useful message", "Send it — no redrafting loop"],
  },
];

export const mockBadges: Badge[] = [
  { id: "b1", name: "First Ember", description: "Complete your first mission", tier: "bronze", earned: true, earnedOn: "Mar 3" },
  { id: "b2", name: "Week Forged", description: "Hit a 7-day streak", tier: "bronze", earned: true, earnedOn: "Mar 10" },
  { id: "b3", name: "Iron Will", description: "Hit a 21-day streak", tier: "silver", earned: true, earnedOn: "Apr 2" },
  { id: "b4", name: "Molten Focus", description: "Complete 25 focus missions", tier: "silver", earned: true, earnedOn: "Apr 18" },
  { id: "b5", name: "Unbreakable", description: "Hit a 60-day streak", tier: "gold", earned: false },
  { id: "b6", name: "Full Forge", description: "Complete every mission category in one week", tier: "gold", earned: false },
];

export const mockLeaderboard: LeaderboardEntry[] = [
  { id: "u2", name: "Devon Marsh", avatarInitial: "D", xp: 5120, streakDays: 34, rank: 1 },
  { id: "u3", name: "Priya Nair", avatarInitial: "P", xp: 4870, streakDays: 22, rank: 2 },
  { id: "u1", name: "Amara Chen", avatarInitial: "A", xp: 3420, streakDays: 27, rank: 3, isCurrentUser: true },
  { id: "u4", name: "Leo Ferreira", avatarInitial: "L", xp: 3110, streakDays: 15, rank: 4 },
  { id: "u5", name: "Sana Ahmed", avatarInitial: "S", xp: 2830, streakDays: 9, rank: 5 },
];

export function getMissionById(id: string): Mission | undefined {
  return mockMissions.find((m) => m.id === id);
}

export const coachTips = [
  "Your focus missions land best before noon — want tomorrow's Deep Work moved to 9 AM?",
  "You've missed outreach missions two Fridays running. Fridays might need a lighter version.",
  "27-day streak — your longest is 41. You're 14 days from a new record.",
];
