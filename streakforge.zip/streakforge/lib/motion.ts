import type { Variants } from "framer-motion";

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
  },
};

export const staggerParent: Variants = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.05,
    },
  },
};

export const staggerChild: Variants = {
  hidden: { opacity: 0, y: 12 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: [0.22, 1, 0.36, 1] },
  },
};

export const popIn: Variants = {
  hidden: { opacity: 0, scale: 0.85 },
  show: {
    opacity: 1,
    scale: 1,
    transition: { type: "spring", stiffness: 260, damping: 20 },
  },
};

// Celebration sequence: badge/XP burst on mission completion.
// Parent orchestrates timing; children (confetti pieces, badge, xp counter)
// key off this via variants + custom delay.
export const celebrationContainer: Variants = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.03, delayChildren: 0.1 },
  },
};

export const celebrationBadge: Variants = {
  hidden: { opacity: 0, scale: 0.4, rotate: -8 },
  show: {
    opacity: 1,
    scale: 1,
    rotate: 0,
    transition: { type: "spring", stiffness: 220, damping: 16, delay: 0.15 },
  },
};

export const confettiPiece: Variants = {
  hidden: { opacity: 0, y: 0, x: 0, rotate: 0 },
  show: (custom: { x: number; y: number; rotate: number; delay: number }) => ({
    opacity: [1, 1, 0],
    y: custom.y,
    x: custom.x,
    rotate: custom.rotate,
    transition: { duration: 1.1, delay: custom.delay, ease: "easeOut" },
  }),
};
